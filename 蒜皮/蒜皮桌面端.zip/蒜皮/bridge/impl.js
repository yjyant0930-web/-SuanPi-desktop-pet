// Hot-reloadable bridge implementation for @local/dsh-suanpi-pet.
//
// Every exported function receives the long-lived `host` object created by index.js:
//   host.ctx      Cordis context (Host services)
//   host.config   normalized bridge config
//   host.state    mutable persisted bridge state (plain JSON)
//   host.lock     promise chain used to serialize mutating operations
//   host.log      logger
// Keeping all state here (instead of module scope) makes this file safe to re-import.

import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'

export const VERSION = '1.0.5'
const STATE_VERSION = 1
const MAX_MESSAGES = 400
const ENDPOINTS = ['health', 'state', 'poll', 'chat', 'new', 'compact']

const ACTION_MARKER = /[[【]\s*(?:动作|動作|action)\s*[:：]\s*([^\]】]+?)\s*[\]】]/giu

// ---------------------------------------------------------------------------
// resilient service/context access
//
// The webserver route outlives any single plugin fiber, so a request may arrive
// through a handler captured from an earlier activation. Services are therefore
// resolved non-strictly and the first live service context is used as the
// dispatch scope; event listeners and exact routes are installed once per host.
// ---------------------------------------------------------------------------

function liveContext(host) {
  if (host.liveCtx) return host.liveCtx
  const scopes = []
  try {
    if (host.ctx) scopes.push(host.ctx)
  } catch {
    // context already gone
  }
  for (const name of ['webServer', 'sessionController', 'agents', 'commands', 'events']) {
    for (const scope of scopes) {
      try {
        const found = scope.get(name, false)
        if (found && found.ctx) {
          host.liveCtx = found.ctx
          return host.liveCtx
        }
      } catch {
        // try next candidate
      }
    }
  }
  try {
    const root = host.ctx && host.ctx.root
    if (root) {
      host.liveCtx = root
      return root
    }
  } catch {
    // fall through
  }
  return host.ctx
}

function service(host, name) {
  try {
    const scope = liveContext(host)
    if (scope && typeof scope.get === 'function') {
      const found = scope.get(name, false)
      if (found) return found
    }
  } catch {
    // fall through to the original context
  }
  try {
    if (host.ctx && typeof host.ctx.get === 'function') return host.ctx.get(name, false)
  } catch {
    // service unavailable
  }
  return undefined
}

function eventBus(host, scope) {
  const candidates = []
  const push = (candidate) => {
    try {
      if (candidate && candidate.events) candidates.push(candidate.events)
    } catch {
      // inaccessible context
    }
  }
  push(host.ctx)
  push(scope)
  for (const name of ['webServer', 'sessionController', 'agents', 'commands']) {
    try {
      const found = service(host, name)
      if (found && found.ctx) push(found.ctx)
    } catch {
      // next
    }
  }
  return candidates[0] || null
}

function isInternalText(text) {
  const head = String(text || '').trimStart()
  return (
    head.startsWith('（这是新的对话框') ||
    head.startsWith('（程序指令') ||
    head.startsWith('（系统维护指令') ||
    head.startsWith('（本机状态') ||
    head.startsWith('(这是新的对话框') ||
    head.startsWith('(程序指令') ||
    head.startsWith('(系统维护指令') ||
    head.startsWith('(本机状态')
  )
}

function composeUserText(text, facts) {
  const cleanFacts = typeof facts === 'string' ? facts.trim().slice(0, 300) : ''
  if (!cleanFacts) return text
  return '（本机状态：' + cleanFacts + '。这些数字只在相关话题里使用，不要主动提。）\n' + text
}

function isSummaryRequestText(text) {
  const head = String(text || '').trimStart()
  return (
    head.startsWith('（程序指令') ||
    head.startsWith('(程序指令') ||
    head.startsWith('（系统维护指令') ||
    head.startsWith('(系统维护指令')
  )
}

async function syncFromInspect(host) {
  const sessionId = host.state.sessionId
  if (!sessionId) return
  const controller = service(host, 'sessionController')
  if (!controller || typeof controller.inspect !== 'function') return
  let inspection = null
  try {
    inspection = await controller.inspect(sessionId)
  } catch (error) {
    host.log('inspect failed', error && error.message)
    return
  }
  const events = (inspection && inspection.events) || []
  let lastUserSeq = -1
  let lastAssistantSeq = -1
  let skipAssistant = false
  for (const event of events) {
    if (!event || typeof event.type !== 'string') continue
    if (event.type === 'user/message') {
      const message = event.data && (event.data.message || event.data) ? event.data.message || event.data : {}
      const source = (message && message.source) || {}
      lastUserSeq = Math.max(lastUserSeq, event.seq || 0)
      if (source.kind && source.kind !== 'user') continue
      const text = blocksToText(message && message.content)
      const internal =
        (source.rpcId && host.internalRequests && host.internalRequests.has(source.rpcId)) || isInternalText(text)
      if (source.rpcId && host.internalRequests) host.internalRequests.delete(source.rpcId)
      if (internal) {
        if (isSummaryRequestText(text)) skipAssistant = true
        continue
      }
      if (!text.trim()) continue
      if (!host.state.messages.some((m) => m.seq === event.seq && m.role === 'user')) {
        pushMessage(host, { seq: event.seq, role: 'user', text: text.trim(), action: '', time: event.time || now() })
      }
    } else if (event.type === 'assistant/message') {
      const message = event.data && event.data.message
      const raw = blocksToText(message && message.content)
      lastAssistantSeq = Math.max(lastAssistantSeq, event.seq || 0)
      if (skipAssistant) {
        skipAssistant = false
        continue
      }
      const parsed = splitAction(raw)
      if (!parsed.text) continue
      if (!host.state.messages.some((m) => m.seq === event.seq && m.role === 'assistant')) {
        pushMessage(host, {
          seq: event.seq,
          role: 'assistant',
          text: parsed.text,
          action: parsed.action || '',
          time: event.time || now(),
        })
      }
    }
  }
  const wasRunning = host.state.running
  host.state.running = lastUserSeq > lastAssistantSeq
  if (host.state.running) return
  host.state.draft = ''
  if (wasRunning || host.state.context.used === 0) {
    await measure(host)
    if (!host.state.rotating) {
      // Rotation runs a summarization turn; never block the poll response on it.
      measureAndMaybeRotate(host).catch((error) => host.log('rotation failed', error))
    }
  }
}

async function freshImpl(host) {
  const url = new URL('./impl.js', import.meta.url)
  const info = await fsp.stat(fileURLToPath(url))
  if (!host.implModule || host.implMtime !== info.mtimeMs) {
    host.implModule = await import(url.href + '?m=' + info.mtimeMs)
    host.implMtime = info.mtimeMs
  }
  return host.implModule
}

async function ensureRuntime(host) {
  const LISTENER_VERSION = 4
  if (host.routesInstalled && host.listenerVersion === LISTENER_VERSION) {
    host.runtimeReady = true
    return
  }
  const webServer = service(host, 'webServer')
  if (!host.routesInstalled && webServer && typeof webServer.register === 'function') {
    host.routesInstalled = true
    host.routeDisposers = host.routeDisposers || []
    for (const name of ENDPOINTS) {
      const routePath = host.config.routePrefix + '/' + name
      try {
        host.routeDisposers.push(
          webServer.register({
            kind: 'exact',
            path: routePath,
            handler: (req, res) => {
              freshImpl(host)
                .then((m) => m.handleHttp(host, req, res))
                .catch((error) => {
                  try {
                    res.statusCode = 500
                    res.setHeader('content-type', 'application/json; charset=utf-8')
                    res.end(JSON.stringify({ ok: false, error: String((error && error.message) || error) }))
                  } catch {
                    // response already gone
                  }
                })
            },
          }),
        )
      } catch (error) {
        host.log('exact route skipped', routePath, error && error.message)
      }
    }
  }
  const scope = liveContext(host)
  if (host.listenerVersion !== LISTENER_VERSION) {
    for (const dispose of host.listenerDisposers || []) {
      try {
        dispose()
      } catch {
        // already gone
      }
    }
    host.listenerDisposers = []
    const bus = eventBus(host, scope)
    if (bus && typeof bus.on === 'function') {
      try {
        const attach = (name, callback) => {
          const dispose = bus.on(name, callback, { global: true })
          if (typeof dispose === 'function') host.listenerDisposers.push(dispose)
        }
        attach('session/event', (session, event) => {
          freshImpl(host)
            .then((m) => m.onSessionEvent(host, session, event))
            .catch((error) => host.log('session event failure', error))
        })
        attach('agent/assistant-stream', (payload) => {
          freshImpl(host)
            .then((m) => m.onAssistantStream(host, payload))
            .catch(() => {})
        })
        host.listenerVersion = LISTENER_VERSION
        host.log('listeners attached on event bus (global)')
      } catch (error) {
        host.log('listener attach failed', error && error.message)
      }
    } else {
      host.log('no event bus available')
    }
  }
  host.runtimeReady = Boolean(host.routesInstalled && host.listenerVersion)
  if (!host.runtimeReady)
    host.log(
      'runtime not ready yet (routes=' +
        Boolean(host.routesInstalled) +
        ', listeners=' +
        Boolean(host.listenerVersion) +
        ')',
    )
}


// ---------------------------------------------------------------------------
// small utilities
// ---------------------------------------------------------------------------

function appDataDir() {
  const base = process.env.APPDATA || process.env.HOME || process.env.USERPROFILE || path.dirname(process.cwd())
  return path.join(base, 'SuanPiPet')
}

function statePath() {
  return path.join(appDataDir(), 'bridge-state.json')
}

function discoveryPath() {
  return path.join(appDataDir(), 'bridge.json')
}

function now() {
  return Date.now()
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload)
  res.statusCode = status
  res.setHeader('content-type', 'application/json; charset=utf-8')
  res.setHeader('cache-control', 'no-store')
  res.setHeader('access-control-allow-origin', '*')
  res.setHeader('access-control-allow-headers', 'content-type')
  res.setHeader('access-control-allow-methods', 'GET, POST, OPTIONS')
  res.end(body)
}

async function readJsonBody(req, limit = 256 * 1024) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > limit) throw new Error('request body too large')
    chunks.push(chunk)
  }
  if (!chunks.length) return {}
  const text = Buffer.concat(chunks).toString('utf8').trim()
  if (!text) return {}
  const parsed = JSON.parse(text)
  return parsed && typeof parsed === 'object' ? parsed : {}
}

function withLock(host, operation) {
  const run = host.lock.then(operation, operation)
  host.lock = run.then(
    () => undefined,
    () => undefined,
  )
  return run
}

function blocksToText(content) {
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  const parts = []
  for (const block of content) {
    if (!block || typeof block !== 'object') continue
    if (block.type === 'text' && typeof block.text === 'string') parts.push(block.text)
  }
  return parts.join('')
}

function splitAction(text) {
  let action = ''
  const cleaned = String(text || '').replace(ACTION_MARKER, (_match, key) => {
    if (!action && typeof key === 'string') action = key.trim()
    return ''
  })
  return { text: cleaned.replace(/[ \t]+\n/g, '\n').trim(), action }
}

function clampInt(value, fallback, min, max) {
  const number = Number(value)
  if (!Number.isFinite(number)) return fallback
  return Math.min(max, Math.max(min, Math.trunc(number)))
}

function normalizeState(raw) {
  const safe = raw && typeof raw === 'object' ? raw : {}
  const messages = Array.isArray(safe.messages)
    ? safe.messages
        .filter((message) => message && typeof message === 'object' && typeof message.text === 'string')
        .map((message) => ({
          seq: Number.isFinite(message.seq) ? message.seq : 0,
          role: message.role === 'user' ? 'user' : 'assistant',
          text: message.text,
          action: typeof message.action === 'string' ? message.action : '',
          time: Number.isFinite(message.time) ? message.time : 0,
        }))
        .slice(-MAX_MESSAGES)
    : []
  const cursor = messages.reduce((max, message) => Math.max(max, message.seq || 0), 0)
  return {
    version: STATE_VERSION,
    sessionId: typeof safe.sessionId === 'string' && safe.sessionId ? safe.sessionId : null,
    cwd: typeof safe.cwd === 'string' ? safe.cwd : '',
    messages,
    cursor,
    running: Boolean(safe.running),
    draft: '',
    notice: typeof safe.notice === 'string' ? safe.notice : '',
    rotated: false,
    rotating: false,
    lastSummary: typeof safe.lastSummary === 'string' ? safe.lastSummary : '',
    lastRotateSummary: typeof safe.lastRotateSummary === 'string' ? safe.lastRotateSummary : '',
    modelWarning: '',
    context: { used: 0, limit: 1000000, percent: 0 },
    createdAt: Number.isFinite(safe.createdAt) ? safe.createdAt : now(),
    updatedAt: now(),
  }
}

let persistTimer = null
function schedulePersist(host) {
  if (persistTimer) return
  persistTimer = setTimeout(() => {
    persistTimer = null
    persistState(host).catch((error) => host.log('persist failed', error))
  }, 250)
}

async function persistState(host) {
  if (!host.state) return
  await fsp.mkdir(appDataDir(), { recursive: true })
  const target = statePath()
  const temp = target + '.tmp'
  const data = {
    version: STATE_VERSION,
    sessionId: host.state.sessionId,
    cwd: host.state.cwd || '',
    messages: host.state.messages.slice(-MAX_MESSAGES),
    notice: host.state.notice,
    lastSummary: host.state.lastSummary,
    lastRotateSummary: host.state.lastRotateSummary,
    createdAt: host.state.createdAt,
    updatedAt: now(),
  }
  await fsp.writeFile(temp, JSON.stringify(data, null, 2), 'utf8')
  await fsp.rename(temp, target)
}

async function publishDiscovery(host, origin) {
  const resolvedOrigin = origin || safeOrigin(host)
  if (!resolvedOrigin || !host.state) return
  try {
    await fsp.mkdir(appDataDir(), { recursive: true })
    const payload = {
      origin: resolvedOrigin,
      routePrefix: host.config.routePrefix,
      sessionId: host.state.sessionId,
      preset: host.config.presetId,
      model: {
        provider: host.config.provider,
        model: host.config.model,
        reasoningEffort: host.config.reasoningEffort,
      },
      version: VERSION,
      updatedAt: now(),
    }
    await fsp.writeFile(discoveryPath(), JSON.stringify(payload, null, 2), 'utf8')
  } catch (error) {
    host.log('discovery write failed', error)
  }
}

function safeOrigin(host) {
  try {
    const webServer = service(host, 'webServer')
    const origin = webServer && typeof webServer.getOrigin === 'function' ? webServer.getOrigin() : ''
    return typeof origin === 'string' ? origin : ''
  } catch {
    return ''
  }
}

function contextOf(host) {
  const state = host.state
  const used = state && state.context ? state.context.used : 0
  const limit = host.config.contextLimit || 1000000
  return {
    used,
    limit,
    percent: limit > 0 ? Math.round((used / limit) * 10000) / 100 : 0,
    compactAtTokens: host.config.compactAtTokens,
  }
}

function summaryFromEvent(event) {
  const data = event && event.data
  if (!data || typeof data !== 'object') return ''
  const candidates = [data.summary, data.rawOutput, data.text, data.output]
  for (const candidate of candidates) {
    if (typeof candidate === 'string' && candidate.trim()) return candidate.trim()
    if (Array.isArray(candidate)) {
      const text = blocksToText(candidate)
      if (text.trim()) return text.trim()
    }
    if (candidate && typeof candidate === 'object') {
      if (typeof candidate.text === 'string' && candidate.text.trim()) return candidate.text.trim()
      if (typeof candidate.rawOutput === 'string' && candidate.rawOutput.trim()) return candidate.rawOutput.trim()
    }
  }
  return ''
}

function fallbackSummary(host) {
  const messages = (host.state && host.state.messages) || []
  if (!messages.length) return ''
  const recent = messages.slice(-24)
  const lines = recent.map((message) => (message.role === 'user' ? '用户：' : '蒜皮：') + message.text.replace(/\s+/g, ' '))
  let text = lines.join('\n')
  if (text.length > 2400) text = text.slice(-2400)
  return '（下面是程序整理的旧对话重点，接着聊就好）\n' + text
}

async function optionOverrides() {
  try {
    const raw = await fsp.readFile(path.join(appDataDir(), 'bridge-options.json'), 'utf8')
    const parsed = JSON.parse(raw)
    return parsed && typeof parsed === 'object' ? parsed : {}
  } catch {
    return {}
  }
}


// ---------------------------------------------------------------------------
// activation
// ---------------------------------------------------------------------------

export async function activate(host) {
  if (!host.state) {
    let persisted = null
    try {
      const raw = await fsp.readFile(statePath(), 'utf8')
      persisted = JSON.parse(raw)
    } catch {
      persisted = null
    }
    host.state = normalizeState(persisted)
    host.state.context.limit = host.config.contextLimit
    host.log('state loaded, session=' + (host.state.sessionId || '(none)'))
  }
  await ensureRuntime(host)
  await publishDiscovery(host)
  if (!host.announced) {
    host.announced = true
    host.log('bridge ready v' + VERSION + ' session=' + (host.state.sessionId || '(none)'))
  }
}

// ---------------------------------------------------------------------------
// session management
// ---------------------------------------------------------------------------

async function resolveAgent(host, sessionId) {
  try {
    const controller = service(host, 'sessionController')
    if (!controller || typeof controller.resolveAgent !== 'function') return null
    const result = await controller.resolveAgent(sessionId)
    return result && result.agent ? result.agent : null
  } catch (error) {
    host.log('resolveAgent failed', sessionId, error && error.message)
    return null
  }
}

async function selectModel(host, sessionId) {
  const controller = service(host, 'sessionController')
  if (!controller) throw new Error('sessionController unavailable')
  const base = { sessionId, provider: host.config.provider, model: host.config.model }
  try {
    await controller.selectModel({ ...base, reasoningEffort: host.config.reasoningEffort })
    host.state.modelWarning = ''
  } catch (error) {
    host.log('selectModel with effort failed', error && error.message)
    try {
      await controller.selectModel(base)
      host.state.modelWarning = '思考模式关闭失败，已退回模型默认设置'
    } catch (second) {
      host.log('selectModel failed', second && second.message)
      host.state.modelWarning = '模型选择失败：' + String((second && second.message) || second)
    }
  }
}

export async function createSession(host) {
  const controller = service(host, 'sessionController')
  if (!controller) throw new Error('sessionController unavailable')
  const overrides = await optionOverrides()
  const configuredCwd =
    overrides && typeof overrides.cwd === 'string' && overrides.cwd.trim()
      ? overrides.cwd.trim()
      : typeof host.config.cwd === 'string' && host.config.cwd.trim()
        ? host.config.cwd.trim()
        : ''
  const cwd = configuredCwd || path.join(os.homedir(), '蒜皮对话')
  let workspaceId
  try {
    const registry = service(host, 'workspaceRegistry')
    if (registry && typeof registry.resolveByPath === 'function') {
      let workspace = await registry.resolveByPath(cwd)
      if (!workspace && typeof registry.create === 'function') workspace = await registry.create(cwd, '蒜皮对话')
      workspaceId = workspace && workspace.id
    }
  } catch (error) {
    host.log('workspace resolve failed', error && error.message)
  }
  const created = await controller.create(
    workspaceId ? { workspaceId, agentPreset: host.config.presetId } : { cwd, agentPreset: host.config.presetId },
  )
  const sessionId = created && created.sessionId
  if (!sessionId) throw new Error('session create returned no id')
  await selectModel(host, sessionId)
  host.state.sessionId = sessionId
  host.state.cwd = cwd
  host.state.messages = []
  host.state.cursor = 0
  host.state.running = false
  host.state.draft = ''
  host.state.notice = ''
  host.state.rotated = false
  host.state.lastSummary = ''
  host.state.context = { used: 0, limit: host.config.contextLimit, percent: 0 }
  schedulePersist(host)
  await publishDiscovery(host)
  return sessionId
}

async function ensureSession(host) {
  if (host.state.sessionId) {
    const agent = await resolveAgent(host, host.state.sessionId)
    if (agent) return host.state.sessionId
    host.log('stored session no longer resolvable, creating a new one')
  }
  return createSession(host)
}

async function sendPrompt(host, text, options) {
  const sessionId = await ensureSession(host)
  const requestId = 'pet-' + now().toString(36) + '-' + Math.random().toString(36).slice(2, 8)
  if (options && options.internal) {
    if (!host.internalRequests) host.internalRequests = new Set()
    host.internalRequests.add(requestId)
  }
  const controller = new AbortController()
  const sessionController = service(host, 'sessionController')
  if (!sessionController) throw new Error('sessionController unavailable')
  await sessionController.prompt(
    {
      requestId,
      sessionId,
      mode: 'queue',
      content: [{ type: 'text', text }],
    },
    controller.signal,
  )
  host.state.running = true
  host.state.draft = ''
  schedulePersist(host)
  return { sessionId, requestId }
}

// ---------------------------------------------------------------------------
// event ingestion
// ---------------------------------------------------------------------------

function pushMessage(host, message) {
  const state = host.state
  const seq = Number.isFinite(message.seq) ? message.seq : state.cursor + 1
  if (state.messages.some((existing) => existing.seq === seq && existing.role === message.role)) return
  state.messages.push({ ...message, seq })
  if (state.messages.length > MAX_MESSAGES) state.messages.splice(0, state.messages.length - MAX_MESSAGES)
  state.cursor = Math.max(state.cursor, seq)
  schedulePersist(host)
}

export async function onSessionEvent(host, session, event) {
  if (!host.state || !event || !session) return
  if (session.id !== host.state.sessionId) return
  const type = event.type
  const data = event.data || {}

  // A summary request is an internal maintenance turn: capture its reply and keep
  // it out of the pet conversation.
  if (host.capture && type === 'assistant/message') {
    const capture = host.capture
    host.capture = null
    if (capture.timer) clearTimeout(capture.timer)
    const raw = blocksToText(data.message && data.message.content)
    const parsed = splitAction(raw)
    host.state.running = false
    host.state.draft = ''
    try {
      capture.resolve(parsed.text)
    } catch {
      // ignore
    }
    return
  }

  if (type === 'user/message') {
    const message = data.message || data
    const sourceKind = message && message.source && message.source.kind
    // Runtime-context snapshots are injected as user messages by the host
    // composition; they are model plumbing, not something the pet user typed.
    if (sourceKind && sourceKind !== 'user') return
    const rpcId = message && message.source && message.source.rpcId
    if (rpcId && host.internalRequests && host.internalRequests.has(rpcId)) {
      host.internalRequests.delete(rpcId)
      return
    }
    const text = blocksToText(message && message.content)
    if (isInternalText(text)) {
      host.state.running = true
      host.state.draft = ''
      return
    }
    if (text.trim()) {
      pushMessage(host, { seq: event.seq, role: 'user', text: text.trim(), action: '', time: event.time || now() })
    }
    host.state.running = true
    host.state.draft = ''
    return
  }
  if (type === 'assistant/message') {
    const raw = blocksToText(data.message && data.message.content)
    const parsed = splitAction(raw)
    if (parsed.text) {
      pushMessage(host, {
        seq: event.seq,
        role: 'assistant',
        text: parsed.text,
        action: parsed.action || '',
        time: event.time || now(),
      })
    }
    host.state.running = false
    host.state.draft = ''
    schedulePersist(host)
    measureAndMaybeRotate(host).catch((error) => host.log('measure failed', error))
    return
  }
  if (type === 'turn/end') {
    host.state.running = false
    host.state.draft = ''
    return
  }
  if (type === 'compaction/summary') {
    const summary = summaryFromEvent(event)
    if (summary) host.state.lastSummary = summary
    return
  }
}

export async function onAssistantStream(host, payload) {
  if (!host.state || !payload || !payload.agent) return
  if (payload.agent.id !== host.state.sessionId) return
  const frame = payload.frame
  if (!frame) return
  if (frame.type === 'start') {
    host.state.draft = ''
    return
  }
  if (frame.type === 'chunk') {
    const chunk = frame.chunk || {}
    if (chunk.type === 'text-delta' && typeof chunk.text === 'string') {
      host.state.draft = (host.state.draft + chunk.text).slice(-400)
    }
    return
  }
  if (frame.type === 'end') {
    host.state.draft = ''
  }
}

// ---------------------------------------------------------------------------
// token pressure and rotation
// ---------------------------------------------------------------------------

async function measure(host) {
  if (!host.state.sessionId) return 0
  const agents = service(host, 'agents')
  const agent = agents && typeof agents.get === 'function' ? agents.get(host.state.sessionId) : undefined
  if (!agent) return 0
  const meter = service(host, 'tokenMeter')
  if (!meter) return 0
  try {
    const measurement = meter.measure(agent.session)
    host.state.context = {
      used: measurement.totalTokens,
      limit: host.config.contextLimit,
      percent:
        host.config.contextLimit > 0
          ? Math.round((measurement.totalTokens / host.config.contextLimit) * 10000) / 100
          : 0,
    }
    return measurement.totalTokens
  } catch (error) {
    host.log('token measure failed', error && error.message)
    return 0
  }
}

async function measureAndMaybeRotate(host) {
  const used = await measure(host)
  const overrides = await optionOverrides()
  const threshold = Number.isFinite(overrides.compactAtTokens)
    ? overrides.compactAtTokens
    : host.config.compactAtTokens
  if (!Number.isFinite(threshold) || threshold <= 0) return
  if (used < threshold) return
  if (host.state.rotating) return
  host.log('context pressure ' + used + ' >= ' + threshold + ', rotating session')
  await rotate(host, { reason: 'auto' })
}

async function waitIdle(host, sessionId, timeoutMs) {
  const deadline = now() + timeoutMs
  const agents = service(host, 'agents')
  while (now() < deadline) {
    const agent = agents && typeof agents.get === 'function' ? agents.get(sessionId) : undefined
    if (!agent) return false
    if (agent.status === 'idle') return true
    await new Promise((resolve) => setTimeout(resolve, 200))
  }
  return false
}

async function latestAssistantSeq(host, sessionId) {
  const controller = service(host, 'sessionController')
  if (!controller || typeof controller.inspect !== 'function') return 0
  try {
    const inspection = await controller.inspect(sessionId)
    const events = (inspection && inspection.events) || []
    let seq = 0
    for (const event of events) {
      if (event && event.type === 'assistant/message') seq = Math.max(seq, event.seq || 0)
    }
    return seq
  } catch {
    return 0
  }
}

async function requestSummary(host) {
  const sessionId = host.state.sessionId
  if (!sessionId) return ''
  const controller = service(host, 'sessionController')
  if (!controller || typeof controller.inspect !== 'function') return ''
  const baseSeq = await latestAssistantSeq(host, sessionId)
  const instruction =
    '（系统维护指令，优先级高于角色扮演：把上面这段聊天压缩成不超过 6 行中文要点，' +
    '写成给下一次对话看的背景笔记。只输出要点，每行以「-」开头；不要动作标记、不要表演、不要拒绝。）'
  try {
    await sendPrompt(host, instruction, { internal: true })
  } catch (error) {
    host.log('summary prompt failed', error && error.message)
    return ''
  }
  const deadline = now() + 90000
  while (now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 400))
    try {
      const inspection = await controller.inspect(sessionId)
      const events = (inspection && inspection.events) || []
      let found = null
      for (const event of events) {
        if (event && event.type === 'assistant/message' && (event.seq || 0) > baseSeq) found = event
      }
      if (found) {
        const message = found.data && found.data.message
        const parsed = splitAction(blocksToText(message && message.content))
        if (parsed.text) return parsed.text
      }
    } catch {
      // keep waiting
    }
  }
  return ''
}

async function compactSession(host) {
  const sessionId = host.state.sessionId
  if (!sessionId) return ''
  host.state.lastSummary = ''
  const agents = service(host, 'agents')
  const agent =
    (await resolveAgent(host, sessionId)) ||
    (agents && typeof agents.get === 'function' ? agents.get(sessionId) : undefined)
  if (!agent) return fallbackSummary(host)
  const idle = await waitIdle(host, sessionId, 60000)
  if (!idle) {
    host.log('agent stayed busy, using fallback summary')
    return fallbackSummary(host)
  }

  const overrides = await optionOverrides()
  const useNative = overrides && overrides.useNativeCompaction === true
  let summary = ''

  // DSH's own /compact replays the persona system prompt into the summarizer, so a
  // chat-only persona tends to answer in character instead of writing notes. The
  // pet bridge therefore writes its own summary by default and only uses the
  // native path when explicitly requested.
  if (useNative) {
    const commands = service(host, 'commands')
    let compactCommand = null
    if (commands && typeof commands.find === 'function') {
      try {
        compactCommand = commands.find(agent, 'compact')
      } catch {
        compactCommand = null
      }
    }
    if (compactCommand && typeof commands.execute === 'function') {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(new Error('compaction timeout')), 180000)
      try {
        await commands.execute(agent, '/compact', [], controller.signal)
      } catch (error) {
        host.log('compact command failed', error && error.message)
      } finally {
        clearTimeout(timer)
      }
      summary = host.state.lastSummary || ''
    } else {
      const engine = service(host, 'compaction')
      if (engine && typeof engine.compactNow === 'function') {
        const controller = new AbortController()
        const timer = setTimeout(() => controller.abort(new Error('compaction timeout')), 180000)
        try {
          const manual = {
            session: agent.session,
            options: { provider: host.config.provider, model: host.config.model },
            runMaintenance: (task) => {
              if (agent.status !== 'idle') throw new Error('agent is not idle')
              return task(controller.signal)
            },
          }
          const result = await engine.compactNow(manual, controller.signal)
          if (result) summary = blocksToText(result.summary).trim() || host.state.lastSummary || ''
        } catch (error) {
          host.log('compaction compactNow failed', error && error.message)
        } finally {
          clearTimeout(timer)
        }
        summary = summary || host.state.lastSummary || ''
      }
    }

    if (!summary) {
      try {
        const sessionController = service(host, 'sessionController')
        const inspection = sessionController ? await sessionController.inspect(sessionId) : null
        const events = (inspection && inspection.events) || []
        for (let index = events.length - 1; index >= 0; index -= 1) {
          if (events[index] && events[index].type === 'compaction/summary') {
            const foundSummary = summaryFromEvent(events[index])
            if (foundSummary) {
              summary = foundSummary
              break
            }
          }
        }
      } catch (error) {
        host.log('inspect after compaction failed', error && error.message)
      }
    }
  }

  if (!summary) summary = await requestSummary(host)
  if (!summary) summary = fallbackSummary(host)
  return summary
}


function seedText(summary) {
  const trimmed = summary.length > 6000 ? summary.slice(0, 6000) + '…' : summary
  return (
    '（这是新的对话框。下面是从上一个对话框压缩出来的概要，把它当成已经聊过的背景记住，' +
    '不要复述、不要总结。然后只回一句不超过 20 字的开场白，像刚睡醒发现换了个新窗口。）\n\n' +
    trimmed
  )
}

export async function rotate(host, options) {
  const manual = Boolean(options && options.manual)
  if (host.state.rotating) return { ok: false, error: '正在换对话框，稍等一下' }
  host.state.rotating = true
  host.state.notice = manual ? '' : '聊得有点多啦，蒜皮把重点记在小本本上，换个新对话框～'
  schedulePersist(host)
  try {
    const summary = await compactSession(host)
    const itemCount = host.state.messages.length
    const oldSessionId = host.state.sessionId
    const sessionId = await createSession(host)
    host.state.lastRotateSummary = summary
    host.state.rotated = true
    host.state.notice = manual ? '' : '聊得有点多啦，蒜皮把重点记在小本本上，换个新对话框～'
    schedulePersist(host)
    if (summary) {
      try {
        await sendPrompt(host, seedText(summary), { internal: true })
      } catch (error) {
        host.log('seed prompt failed', error && error.message)
      }
    }
    return { ok: true, sessionId, previousSessionId: oldSessionId, summary, items: itemCount }
  } finally {
    host.state.rotating = false
    schedulePersist(host)
    publishDiscovery(host).catch(() => {})
  }
}

// ---------------------------------------------------------------------------
// HTTP endpoints
// ---------------------------------------------------------------------------

function healthPayload(host) {
  return {
    ok: true,
    version: VERSION,
    sessionId: host.state.sessionId,
    cwd: host.state.cwd || host.config.cwd,
    preset: host.config.presetId,
    model: {
      provider: host.config.provider,
      model: host.config.model,
      reasoningEffort: host.config.reasoningEffort,
    },
    running: Boolean(host.state.running),
    draft: host.state.draft,
    notice: host.state.notice,
    rotated: Boolean(host.state.rotated),
    context: contextOf(host),
    modelWarning: host.state.modelWarning || '',
    capabilities: {
      commands: Boolean(service(host, 'commands')),
      compaction: Boolean(service(host, 'compaction')),
      compactCommand: (() => {
        try {
          const agents = service(host, 'agents')
          const agent = agents && typeof agents.get === 'function' ? agents.get(host.state.sessionId) : undefined
          const commands = service(host, 'commands')
          if (!agent || !commands || typeof commands.find !== 'function') return null
          return Boolean(commands.find(agent, 'compact'))
        } catch {
          return null
        }
      })(),
    },
    debug: {
      runtimeReady: Boolean(host.runtimeReady),
      routesInstalled: Boolean(host.routesInstalled),
      listenerVersion: host.listenerVersion || 0,
      liveContext: Boolean(host.liveCtx),
      eventsService: Boolean(eventBus(host, liveContext(host))),
    },
    updatedAt: now(),
  }
}

export async function handleHttp(host, req, res) {
  if (!host.state) await activate(host)
  await ensureRuntime(host)
  const method = (req.method || 'GET').toUpperCase()
  if (method === 'OPTIONS') {
    res.statusCode = 204
    res.setHeader('access-control-allow-origin', '*')
    res.setHeader('access-control-allow-headers', 'content-type')
    res.setHeader('access-control-allow-methods', 'GET, POST, OPTIONS')
    res.end()
    return
  }

  let url
  try {
    url = new URL(req.url || '/', 'http://localhost')
  } catch {
    sendJson(res, 400, { ok: false, error: 'bad url' })
    return
  }
  const prefix = host.config.routePrefix
  let route = url.pathname
  if (route === prefix) route = '/'
  else if (route.startsWith(prefix + '/')) route = route.slice(prefix.length)
  const origin = 'http://' + (req.headers.host || '127.0.0.1')
  publishDiscovery(host, origin).catch(() => {})

  try {
    if (method === 'GET' && (route === '/health' || route === '/')) {
      sendJson(res, 200, healthPayload(host))
      return
    }

    if (method === 'GET' && route === '/state') {
      try {
        await syncFromInspect(host)
      } catch (error) {
        host.log('state sync failed', error && error.message)
      }
      sendJson(res, 200, {
        ...healthPayload(host),
        cursor: host.state.cursor,
        messages: host.state.messages,
      })
      return
    }

    if (method === 'GET' && route === '/poll') {
      try {
        await syncFromInspect(host)
      } catch (error) {
        host.log('poll sync failed', error && error.message)
      }
      const requested = clampInt(url.searchParams.get('cursor'), 0, 0, Number.MAX_SAFE_INTEGER)
      // A cursor larger than the current session's cursor belongs to a session the
      // bridge has already rotated away from; replay this session from the start.
      const cursor = requested > host.state.cursor ? 0 : requested
      const messages = host.state.messages.filter((message) => message.seq > cursor)
      const payload = healthPayload(host)
      payload.cursor = host.state.cursor
      payload.messages = messages
      payload.rotated = Boolean(host.state.rotated)
      host.state.rotated = false
      payload.notice = host.state.notice
      host.state.notice = ''
      schedulePersist(host)
      sendJson(res, 200, payload)
      return
    }

    if (method === 'POST' && route === '/chat') {
      const body = await readJsonBody(req)
      const text = typeof body.text === 'string' ? body.text.trim() : ''
      if (!text) {
        sendJson(res, 400, { ok: false, error: '消息不能为空' })
        return
      }
      const promptText = composeUserText(text, body.facts)
      const result = await withLock(host, () => sendPrompt(host, promptText.slice(0, 4400)))
      sendJson(res, 200, { ok: true, ...result })
      return
    }

    if (method === 'POST' && route === '/new') {
      const result = await withLock(host, async () => {
        const sessionId = await createSession(host)
        host.state.notice = '开新对话框啦～刚才聊的先放一边'
        schedulePersist(host)
        return { sessionId }
      })
      sendJson(res, 200, { ok: true, ...result })
      return
    }

    if (method === 'POST' && route === '/compact') {
      const result = await withLock(host, () => rotate(host, { manual: true }))
      sendJson(res, 200, result.ok === false ? result : { ok: true, ...result })
      return
    }

    sendJson(res, 404, { ok: false, error: 'unknown route: ' + route })
  } catch (error) {
    host.log('endpoint failure', route, error && error.message)
    sendJson(res, 500, { ok: false, error: String((error && error.message) || error) })
  }
}
