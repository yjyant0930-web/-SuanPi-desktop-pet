// @local/dsh-suanpi-pet — Host plugin: bridge between the SuanPi desktop pet and DSH.
//
// Two stability rules make this module safe to reload:
//   1. The webserver route and the long-lived bridge host live on a process-global
//      registry, so a re-activation refreshes the Cordis context instead of trying
//      to register the same path twice.
//   2. All behavior lives in ./impl.js, which is re-imported when its mtime changes,
//      so bridge logic can be fixed without restarting the DSH host.
import { stat } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'

export const name = 'suanpi-pet-bridge'
export const inject = ['webServer', 'sessionController', 'agents']

const IMPL_PATH = fileURLToPath(new URL('./impl.js', import.meta.url))
const REGISTRY_KEY = '__dshSuanpiPetBridge__'

let impl = null
let implMtime = -1

async function loadImpl() {
  const info = await stat(IMPL_PATH)
  if (!impl || info.mtimeMs !== implMtime) {
    const fresh = await import(new URL('./impl.js?m=' + info.mtimeMs, import.meta.url).href)
    impl = fresh
    implMtime = info.mtimeMs
  }
  return impl
}

function normalizeConfig(raw) {
  const config = raw && typeof raw === 'object' ? raw : {}
  return {
    cwd: typeof config.cwd === 'string' ? config.cwd : '',
    presetId: typeof config.presetId === 'string' && config.presetId ? config.presetId : 'suanpi',
    provider: typeof config.provider === 'string' && config.provider ? config.provider : 'deepseek-official',
    model: typeof config.model === 'string' && config.model ? config.model : 'deepseek-flash',
    reasoningEffort: typeof config.reasoningEffort === 'string' ? config.reasoningEffort : 'off',
    compactAtTokens: Number.isFinite(config.compactAtTokens) ? config.compactAtTokens : 120000,
    contextLimit: Number.isFinite(config.contextLimit) ? config.contextLimit : 1000000,
    routePrefix:
      typeof config.routePrefix === 'string' && config.routePrefix.startsWith('/')
        ? config.routePrefix.replace(/\/+$/, '')
        : '/suanpi',
  }
}

function getRegistry() {
  const existing = globalThis[REGISTRY_KEY]
  if (existing && existing.host) return existing
  return null
}

export function apply(ctx, rawConfig) {
  const log = (...args) => console.log('[suanpi]', ...args)
  let registry = getRegistry()

  if (!registry) {
    const host = {
      ctx,
      config: normalizeConfig(rawConfig),
      state: null,
      lock: Promise.resolve(),
      log,
    }
    registry = { host, disposeRoute: null, listeners: [], generation: 0 }
    globalThis[REGISTRY_KEY] = registry

    try {
      registry.disposeRoute = ctx.webServer.register({
        kind: 'prefix',
        path: host.config.routePrefix,
        handler: async (req, res) => {
          try {
            const m = await loadImpl()
            await m.handleHttp(registry.host, req, res)
          } catch (error) {
            log('http failure', error)
            try {
              res.statusCode = 500
              res.setHeader('content-type', 'application/json; charset=utf-8')
              res.setHeader('cache-control', 'no-store')
              res.end(JSON.stringify({ ok: false, error: String((error && error.message) || error) }))
            } catch {
              // response already gone
            }
          }
        },
      })
    } catch (error) {
      log('route registration failed', error)
    }
  } else {
    registry.host.ctx = ctx
    registry.host.config = normalizeConfig(rawConfig)
    registry.host.log = log
  }

  registry.generation += 1
  const generation = registry.generation
  const host = registry.host
  const currentRegistry = registry

  // Replace any listeners registered by an earlier activation of this plugin.
  for (const dispose of currentRegistry.listeners) {
    try {
      dispose()
    } catch (error) {
      log('listener dispose failure', error)
    }
  }
  currentRegistry.listeners = []

  const onSessionEvent = (session, event) => {
    if (currentRegistry.generation !== generation) return
    loadImpl()
      .then((m) => m.onSessionEvent(host, session, event))
      .catch((error) => log('session event failure', error))
  }
  const onAssistantStream = (payload) => {
    if (currentRegistry.generation !== generation) return
    loadImpl()
      .then((m) => m.onAssistantStream(host, payload))
      .catch(() => {})
  }
  ctx.on('session/event', onSessionEvent)
  ctx.on('agent/assistant-stream', onAssistantStream)
  currentRegistry.listeners.push(() => ctx.off('session/event', onSessionEvent))
  currentRegistry.listeners.push(() => ctx.off('agent/assistant-stream', onAssistantStream))

  host.ctx = ctx
  loadImpl()
    .then((m) => m.activate(host))
    .catch((error) => log('activate failure', error))

  // The shared route and host outlive one activation; only the listeners are owned
  // by this plugin fiber. The route is disposed when the registry is replaced by a
  // future process (globalThis is process-scoped, so normally never).
  return () => {
    for (const dispose of currentRegistry.listeners) {
      try {
        dispose()
      } catch (error) {
        log('listener dispose failure', error)
      }
    }
    currentRegistry.listeners = []
  }
}
