# @local/dsh-suanpi-pet

蒜皮桌宠 ↔ DSH 的桥。装进 `desktop` profile 后提供两件东西：

1. **`suanpi` Agent preset**：只挂 `dsh-persona`（`complete: true`、`includeRuntimeContext: false`），系统提示词就是 `persona/system-prompt.md` 的全文，所以这个会话里的模型只扮演蒜皮，没有工具、没有环境上下文。
2. **`suanpi-pet-bridge` Host 插件**：在现有 Web 服务上注册 `/suanpi/*` 路由（本机回环，不走 `/api` 鉴权），把桌宠的聊天转进专属蒜皮会话，并处理上下文压缩与换新会话。

## HTTP 接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/suanpi/health` | 状态、当前会话、模型、上下文用量 |
| POST | `/suanpi/chat` | `{"text":"...","facts":"本次启动偷吃次数：7 次"}` 发一条消息；`facts` 可选，会被包成隐藏的本机状态上下文 |
| GET | `/suanpi/poll?cursor=N` | 拉取 `seq > cursor` 的新消息、`draft` 流式草稿、`notice`、`rotated` |
| GET | `/suanpi/state` | 完整状态与最近消息（桌宠重启恢复用） |
| POST | `/suanpi/new` | 立即开新会话 |
| POST | `/suanpi/compact` | 压缩成概要并换新会话，返回 `summary` |

桌宠通过 `%APPDATA%\SuanPiPet\bridge.json` 找到 `origin`（端口每次启动可能不同）。

## 行为

- 首次聊天时创建会话：`agentPreset` = `suanpi`，工作目录与 DSH 工作区都是 `E:\蒜皮对话`（配置 `cwd`，也可由 `%APPDATA%\SuanPiPet\bridge-options.json` 的 `cwd` 覆盖），并 `selectModel` 成 `deepseek-official / deepseek-flash / reasoningEffort: off`（关闭思考模式）。
- `poll` 每次都会从 DSH 会话日志同步，所以不依赖进程内事件也能拿到回复；桌宠发消息与 DSH 界面里手动发消息都会同步显示。
- `chat` 的 `facts` 会以「（本机状态：…）」前缀拼进用户消息，并标记为内部消息：模型能看到，但不会出现在 `poll` 的对话消息里（前端靠自己的本地回显显示）。
- 上下文超过 `compactAtTokens`（默认 120000，可用 `bridge-options.json` 覆盖）时：先用 `/compact` 把旧历史压缩成摘要（历史太少压不动时由模型写一段要点），创建新会话，并把摘要作为背景种子发进去，然后 `rotated: true` 通知桌宠重置换新。
- 实现逻辑在 `impl.js`，按 mtime 热重载，改完不需要重启 DSH；路由与事件监听会从活动上下文自动恢复，插件重新激活也不会重复占路。

## 配置项

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `cwd` | `E:\蒜皮对话` | 会话工作目录（DSH 工作区同名） |
| `presetId` | `suanpi` | 使用的 Agent preset |
| `provider` / `model` | `deepseek-official` / `deepseek-flash` | 会话模型 |
| `reasoningEffort` | `off` | 关闭思考模式 |
| `compactAtTokens` | `120000` | 超过该 token 数自动压缩换新（`0` 关闭自动） |
| `contextLimit` | `1000000` | 展示用上下文上限 |
| `routePrefix` | `/suanpi` | 路由前缀 |

`%APPDATA%\SuanPiPet\bridge-options.json` 可在不重启 DSH 的情况下覆盖任意一项，例如
`{"cwd":"E:\\蒜皮对话","compactAtTokens":60000}`；另有一个 `useNativeCompaction`
开关（默认 `false`）：默认由桥让模型写 6 行中文要点当代替 DSH 原生 `/compact`，
因为原生压缩会把蒜皮人设系统提示词一起喂给摘要器，摘要容易变成角色台词。

## 文件

`index.js`（路由/事件接线，热重载 impl）、`impl.js`（全部行为）、`cordis.patch.yml`（preset + 插件行）、`locale/`、`icon.svg`。
