@echo off
start "" "%~dp0SuanPiPet.exe"
